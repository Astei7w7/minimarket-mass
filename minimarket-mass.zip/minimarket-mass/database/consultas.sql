-- ============================================================
-- consultas.sql · Las 8 consultas pedidas + bonus
-- Cada consulta indica qué responde. Ejecutar después de datos.sql.
-- ============================================================
USE minimarket_mass;

-- 1. Cantidad de ventas y total vendido hoy, por tienda
-- Responde: ¿cuántas ventas se hicieron hoy y cuánto se vendió en cada tienda?
SELECT t.codigo, t.nombre AS tienda,
       COUNT(v.id)                AS cantidad_ventas,
       COALESCE(SUM(v.total), 0)  AS total_vendido
FROM tienda t
LEFT JOIN venta v ON v.tienda_id = t.id
                 AND DATE(v.fecha) = CURDATE()
                 AND v.estado = 'EMITIDA'
GROUP BY t.id, t.codigo, t.nombre
ORDER BY t.codigo;

-- 2. Los 10 productos más vendidos del mes
-- Responde: ¿qué 10 productos tienen más unidades vendidas en el mes actual?
SELECT p.nombre AS producto, c.nombre AS categoria,
       SUM(dv.cantidad)    AS unidades_vendidas,
       SUM(dv.total_linea) AS monto_total
FROM detalle_venta dv
JOIN venta v     ON v.id = dv.venta_id
JOIN producto p  ON p.id = dv.producto_id
JOIN categoria c ON c.id = p.categoria_id
WHERE v.estado = 'EMITIDA'
  AND v.fecha >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
  AND v.fecha <  DATE_FORMAT(CURDATE(), '%Y-%m-01') + INTERVAL 1 MONTH
GROUP BY p.id, p.nombre, c.nombre
ORDER BY unidades_vendidas DESC, monto_total DESC
LIMIT 10;

-- 3. Stock actual de una tienda (Mass Cayma), de menor a mayor,
--    marcando los productos con menos de 10 unidades
-- Responde: ¿qué hay en el almacén de Cayma y qué falta reponer?
SELECT p.nombre AS producto, u.abreviatura AS unidad, s.cantidad,
       CASE WHEN s.cantidad < 10 THEN 'BAJO: reponer' ELSE 'OK' END AS alerta
FROM stock s
JOIN tienda t         ON t.id = s.tienda_id
JOIN producto p       ON p.id = s.producto_id
JOIN unidad_medida u  ON u.id = p.unidad_medida_id
WHERE t.codigo = 'MASS-CAY'
ORDER BY s.cantidad ASC, p.nombre;

-- 4. Total vendido por medio de pago
-- Responde: ¿cuánto se cobró con efectivo, tarjeta, Yape y Plin? (solo ventas emitidas)
SELECT pv.medio_pago, COUNT(*) AS cantidad_pagos, SUM(pv.monto) AS total_cobrado
FROM pago_venta pv
JOIN venta v ON v.id = pv.venta_id
WHERE v.estado = 'EMITIDA' AND pv.estado = 'APLICADO'
GROUP BY pv.medio_pago
ORDER BY total_cobrado DESC;

-- 5. Ventas y total de cada cajero en un turno de caja
-- Responde: ¿cuántas ventas y cuánto vendió cada cajero en cada turno?
SELECT ct.id AS turno, u.nombre AS cajero, t.nombre AS tienda, ct.estado, ct.apertura,
       COUNT(v.id)               AS cantidad_ventas,
       COALESCE(SUM(v.total), 0) AS total_vendido
FROM caja_turno ct
JOIN usuario u ON u.id = ct.usuario_id
JOIN tienda t  ON t.id = ct.tienda_id
LEFT JOIN venta v ON v.caja_turno_id = ct.id AND v.estado = 'EMITIDA'
GROUP BY ct.id, u.nombre, t.nombre, ct.estado, ct.apertura
ORDER BY ct.id;

-- 6. Cuadre de caja de un turno: monto inicial + ventas en efectivo
-- Responde: ¿cuánto debería haber en la caja de Ana Quispe (Cayma) en su turno de hoy?
-- (el efectivo cuenta lo recibido menos el vuelto, que es el monto del pago)
SELECT u.nombre AS cajero, ct.id AS turno, ct.monto_inicial,
       COALESCE(SUM(pv.monto), 0)                    AS ventas_en_efectivo,
       ct.monto_inicial + COALESCE(SUM(pv.monto), 0) AS esperado_en_caja
FROM caja_turno ct
JOIN usuario u ON u.id = ct.usuario_id
LEFT JOIN venta v       ON v.caja_turno_id = ct.id AND v.estado = 'EMITIDA'
LEFT JOIN pago_venta pv ON pv.venta_id = v.id AND pv.medio_pago = 'efectivo' AND pv.estado = 'APLICADO'
WHERE u.usuario = 'ana.cayma' AND ct.estado = 'ABIERTO'
GROUP BY ct.id, u.nombre, ct.monto_inicial;

-- 7. Productos sin ventas en los últimos 30 días
-- Responde: ¿qué productos del catálogo no rotaron en el último mes?
SELECT p.id, p.nombre, c.nombre AS categoria, p.precio
FROM producto p
JOIN categoria c ON c.id = p.categoria_id
WHERE p.activo = 1
  AND NOT EXISTS (
        SELECT 1
        FROM detalle_venta dv
        JOIN venta v ON v.id = dv.venta_id
        WHERE dv.producto_id = p.id
          AND v.estado = 'EMITIDA'
          AND v.fecha >= NOW() - INTERVAL 30 DAY)
ORDER BY p.nombre;

-- 8. Ventas pagadas con más de un medio de pago
-- Responde: ¿qué ventas se pagaron combinando varios medios?
SELECT v.id AS venta, CONCAT(v.serie, '-', v.correlativo) AS comprobante, t.nombre AS tienda, v.total,
       COUNT(pv.id) AS cantidad_medios,
       GROUP_CONCAT(CONCAT(pv.medio_pago, ' S/ ', pv.monto) ORDER BY pv.medio_pago SEPARATOR ' + ') AS detalle_pagos
FROM venta v
JOIN tienda t      ON t.id = v.tienda_id
JOIN pago_venta pv ON pv.venta_id = v.id AND pv.estado = 'APLICADO'
WHERE v.estado = 'EMITIDA'
GROUP BY v.id, v.serie, v.correlativo, t.nombre, v.total
HAVING COUNT(pv.id) > 1
ORDER BY v.id;

-- BONUS. Total de IGV por mes
-- Responde: ¿cuánto IGV se generó cada mes? (ventas emitidas)
SELECT DATE_FORMAT(fecha, '%Y-%m') AS periodo,
       COUNT(*) AS cantidad_ventas, SUM(subtotal) AS base_imponible, SUM(igv) AS total_igv
FROM venta
WHERE estado = 'EMITIDA'
GROUP BY DATE_FORMAT(fecha, '%Y-%m')
ORDER BY periodo DESC;
