-- ============================================================
-- datos.sql · Datos de ejemplo coherentes con las reglas de negocio
-- 3 tiendas · 20 productos peruanos · 2 cajeros por tienda · 13 ventas
-- Ejecutar DESPUÉS de schema.sql. Las ventas pasan por los triggers:
-- descuentan stock, dejan kardex y toman el correlativo automático.
-- Clave de todos los usuarios de ejemplo: "password" (hash bcrypt, solo demo).
-- ============================================================
USE minimarket_mass;

INSERT INTO distrito (nombre) VALUES ('Cayma'),('Cerro Colorado'),('Yanahuara');

INSERT INTO tienda (distrito_id, codigo, nombre, direccion, telefono, serie_boleta, serie_factura) VALUES
 (1,'MASS-CAY','Mass Cayma','Av. Ejército 1205, Cayma','054-251001','B001','F001'),
 (2,'MASS-CCO','Mass Cerro Colorado','Calle Los Pinos 340, Cerro Colorado','054-251002','B002','F002'),
 (3,'MASS-YAN','Mass Yanahuara','Calle Jerusalén 215, Yanahuara',NULL,'B003','F003');

INSERT INTO usuario (tienda_id, nombre, usuario, clave, rol) VALUES
 (1,'Ana Quispe','ana.cayma','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','cajero'),
 (1,'Luis Mamani','luis.cayma','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','cajero'),
 (1,'Carla Ramos','admin.cayma','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','administrador'),
 (1,'Pedro Huamán','alma.cayma','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','almacenero'),
 (2,'María Flores','maria.cco','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','cajero'),
 (2,'José Paredes','jose.cco','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','cajero'),
 (2,'Rosa Vargas','admin.cco','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','administrador'),
 (2,'Diego Chávez','alma.cco','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','almacenero'),
 (3,'Elena Torres','elena.yan','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','cajero'),
 (3,'Miguel Soto','miguel.yan','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','cajero'),
 (3,'Sofía Mendoza','admin.yan','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','administrador'),
 (3,'Andrés Quispe','alma.yan','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','almacenero');

INSERT INTO cliente (tipo_documento, numero_documento, nombre, telefono) VALUES
 ('DNI','45678901','Juan Pérez García','959111222'),
 ('DNI','71234567','María López Fernández',NULL),
 ('RUC','20123456789','Comercial Andina S.A.C.','054-222333'),
 ('RUC','20567890123','Distribuidora Sur E.I.R.L.',NULL),
 ('DNI','78901234','Carlos Rivera Morales','958333444'),
 ('DNI','62345678','Lucía Castro Díaz',NULL);

INSERT INTO categoria (nombre) VALUES ('Lácteos'),('Abarrotes'),('Bebidas'),('Snacks'),('Limpieza'),('Cuidado personal'),('Panadería'),('Congelados');
INSERT INTO marca (nombre, es_propia) VALUES ('Gloria',0),('Laive',0),('Costeño',0),('Primor',0),('Mass',1),('Don Vittorio',0),('Inca Kola',0),('Coca-Cola',0),('San Luis',0),('Lay''s',0),('Oreo',0),('Sublime',0),('Ace',0),('Sapolio',0),('Bolívar',0),('Head & Shoulders',0),('Bimbo',0),('San Fernando',0),('Braedt',0);
INSERT INTO unidad_medida (abreviatura, nombre, permite_decimales) VALUES ('UND','Unidad',0),('KG','Kilogramo',1),('L','Litro',1),('PAQ','Paquete',0);

INSERT INTO producto (categoria_id, marca_id, unidad_medida_id, codigo_barras, nombre, precio) VALUES
 (1,1,1,'7750001001379','Leche evaporada Gloria 400 g',4.50),
 (1,1,1,'7750001002741','Yogurt Gloria natural 1 L',6.90),
 (1,2,2,'7750001004110','Queso fresco Laive (por kg)',24.90),
 (2,3,1,'7750001005483','Arroz Costeño 1 kg',4.20),
 (2,4,1,'7750001006855','Aceite Primor 1 L',9.50),
 (2,5,1,'7750001008224','Azúcar rubia Mass 1 kg',3.80),
 (2,6,1,'7750001009597','Fideos spaghetti Don Vittorio 500 g',2.90),
 (3,7,1,'7750001010968','Inca Kola 1.5 L',5.50),
 (3,8,1,'7750001012337','Coca-Cola 1.5 L',5.50),
 (3,9,1,'7750001013709','Agua San Luis 625 ml',1.50),
 (4,10,1,'7750001015079','Papas Lay''s clásicas 150 g',4.80),
 (4,11,1,'7750001016441','Galletas Oreo 36 g',1.80),
 (4,12,1,'7750001017813','Chocolate Sublime 30 g',1.50),
 (5,13,1,'7750001019183','Detergente Ace 1 kg',8.90),
 (5,14,1,'7750001020554','Lavavajilla Sapolio 500 ml',4.20),
 (6,15,4,'7750001021926','Jabón Bolívar x3',3.50),
 (6,16,1,'7750001023296','Shampoo Head & Shoulders 180 ml',12.90),
 (7,17,1,'7750001024668','Pan de molde Bimbo 500 g',6.50),
 (8,18,1,'7750001026037','Pollo entero congelado 1.5 kg',18.90),
 (8,19,1,'7750001027409','Hamburguesas de res x4',11.50);

-- Stock inicial: cada tienda tiene su propio saldo de cada producto
INSERT INTO stock (tienda_id, producto_id, cantidad)
SELECT t.id, p.id,
       CASE t.id WHEN 1 THEN 40 + (p.id % 20) WHEN 2 THEN 30 + (p.id % 15) ELSE 25 + (p.id % 18) END
FROM tienda t CROSS JOIN producto p;

INSERT INTO caja (tienda_id, numero) VALUES (1,1),(1,2),(2,1),(2,2),(3,1),(3,2);

-- Turnos históricos (se cierran después de sus ventas)
INSERT INTO caja_turno (caja_id, tienda_id, usuario_id, apertura, monto_inicial) VALUES
 (1,1,1,NOW() - INTERVAL 40 DAY,150.00),
 (3,2,5,NOW() - INTERVAL 40 DAY,120.00),
 (5,3,9,NOW() - INTERVAL 12 DAY,130.00);

-- Venta 1: Cayma · boleta B001 · total S/ 19.90
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (1,1,1,'BOLETA','B001',0,NOW() - INTERVAL 40 DAY,16.86,3.04,19.90);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (1,16,2,3.50,7.00),
 (1,17,1,12.90,12.90);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (1,'efectivo',19.90);
INSERT INTO pago_efectivo (pago_venta_id, monto_recibido, vuelto) VALUES (1,20,0.10);

-- Venta 2: Cerro Colorado · boleta B002 · total S/ 18.40
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (2,2,NULL,'BOLETA','B002',0,NOW() - INTERVAL 40 DAY,15.59,2.81,18.40);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (2,20,1,11.50,11.50),
 (2,2,1,6.90,6.90);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (2,'yape',18.40);
INSERT INTO pago_billetera (pago_venta_id, codigo_operacion, telefono_origen) VALUES (2,'YAPE-20261014','958101822');

-- Venta 3: Yanahuara · factura F003 · total S/ 83.40
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (3,3,3,'FACTURA','F003',0,NOW() - INTERVAL 12 DAY,70.68,12.72,83.40);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (3,4,6,4.20,25.20),
 (3,5,3,9.50,28.50),
 (3,6,4,3.80,15.20),
 (3,7,5,2.90,14.50);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (3,'tarjeta',50.04);
INSERT INTO pago_tarjeta (pago_venta_id, tipo_tarjeta, marca, ultimos_4, codigo_autorizacion) VALUES (3,'DEBITO','Visa','4211','AUT100239');
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (3,'efectivo',33.36);
INSERT INTO pago_efectivo (pago_venta_id, monto_recibido, vuelto) VALUES (4,40,6.64);

-- Venta 4: Yanahuara · boleta B003 · total S/ 22.00
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (3,3,NULL,'BOLETA','B003',0,NOW() - INTERVAL 12 DAY,18.64,3.36,22.00);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (4,8,2,5.50,11.00),
 (4,9,2,5.50,11.00);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (4,'plin',22.00);
INSERT INTO pago_billetera (pago_venta_id, codigo_operacion, telefono_origen) VALUES (5,'PLIN-20261035','958104555');

-- Cierre de turnos históricos: monto final = inicial + efectivo cobrado
UPDATE caja_turno SET estado='CERRADO', cierre=apertura + INTERVAL 8 HOUR, monto_final=169.90 WHERE id=1;
UPDATE caja_turno SET estado='CERRADO', cierre=apertura + INTERVAL 8 HOUR, monto_final=120 WHERE id=2;
UPDATE caja_turno SET estado='CERRADO', cierre=apertura + INTERVAL 8 HOUR, monto_final=163.36 WHERE id=3;

-- Turnos abiertos de hoy (Ana y Luis en Cayma, María en Cerro Colorado, Elena en Yanahuara)
INSERT INTO caja_turno (caja_id, tienda_id, usuario_id, apertura, monto_inicial) VALUES
 (1,1,1,TIMESTAMP(CURDATE(),'08:00:00'),150.00),
 (2,1,2,TIMESTAMP(CURDATE(),'14:00:00'),100.00),
 (3,2,5,TIMESTAMP(CURDATE(),'08:30:00'),120.00),
 (5,3,9,TIMESTAMP(CURDATE(),'09:00:00'),130.00);

-- Venta 5: Cayma · boleta B001 · total S/ 20.00
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (1,4,1,'BOLETA','B001',0,TIMESTAMP(CURDATE(),'08:30:00'),16.95,3.05,20.00);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (5,1,2,4.50,9.00),
 (5,8,2,5.50,11.00);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (5,'efectivo',20.00);
INSERT INTO pago_efectivo (pago_venta_id, monto_recibido, vuelto) VALUES (6,20,0.00);

-- Venta 6: Cayma · factura F001 · total S/ 47.60
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (1,4,3,'FACTURA','F001',0,TIMESTAMP(CURDATE(),'09:10:00'),40.34,7.26,47.60);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (6,4,5,4.20,21.00),
 (6,5,2,9.50,19.00),
 (6,6,2,3.80,7.60);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (6,'tarjeta',28.56);
INSERT INTO pago_tarjeta (pago_venta_id, tipo_tarjeta, marca, ultimos_4, codigo_autorizacion) VALUES (7,'DEBITO','Visa','4359','AUT100291');
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (6,'yape',19.04);
INSERT INTO pago_billetera (pago_venta_id, codigo_operacion, telefono_origen) VALUES (8,'YAPE-20261056','958107288');

-- Venta 7: Cayma · boleta B001 · total S/ 9.90
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (1,5,NULL,'BOLETA','B001',0,TIMESTAMP(CURDATE(),'14:20:00'),8.39,1.51,9.90);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (7,11,1,4.80,4.80),
 (7,12,2,1.80,3.60),
 (7,13,1,1.50,1.50);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (7,'plin',9.90);
INSERT INTO pago_billetera (pago_venta_id, codigo_operacion, telefono_origen) VALUES (9,'PLIN-20261063','958108199');

-- Venta 8: Cerro Colorado · boleta B002 · total S/ 35.00
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (2,6,2,'BOLETA','B002',0,TIMESTAMP(CURDATE(),'09:00:00'),29.66,5.34,35.00);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (8,14,2,8.90,17.80),
 (8,15,1,4.20,4.20),
 (8,18,2,6.50,13.00);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (8,'efectivo',35.00);
INSERT INTO pago_efectivo (pago_venta_id, monto_recibido, vuelto) VALUES (10,40,5.00);

-- Venta 9: Cerro Colorado · factura F002 · total S/ 39.10
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (2,6,4,'FACTURA','F002',0,TIMESTAMP(CURDATE(),'10:45:00'),33.14,5.96,39.10);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (9,19,1,18.90,18.90),
 (9,20,1,11.50,11.50),
 (9,7,3,2.90,8.70);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (9,'tarjeta',39.10);
INSERT INTO pago_tarjeta (pago_venta_id, tipo_tarjeta, marca, ultimos_4, codigo_autorizacion) VALUES (11,'DEBITO','Visa','4507','AUT100343');

-- Venta 10: Yanahuara · boleta B003 · total S/ 15.00
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (3,7,5,'BOLETA','B003',0,TIMESTAMP(CURDATE(),'09:40:00'),12.71,2.29,15.00);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (10,9,1,5.50,5.50),
 (10,10,2,1.50,3.00),
 (10,18,1,6.50,6.50);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (10,'yape',15.00);
INSERT INTO pago_billetera (pago_venta_id, codigo_operacion, telefono_origen) VALUES (12,'YAPE-20261084','958110932');

-- Venta 11: Yanahuara · boleta B003 · total S/ 24.62
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (3,7,NULL,'BOLETA','B003',0,TIMESTAMP(CURDATE(),'11:05:00'),20.86,3.76,24.62);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (11,2,1,6.90,6.90),
 (11,3,0.350,24.90,8.72),
 (11,1,2,4.50,9.00);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (11,'efectivo',10.00);
INSERT INTO pago_efectivo (pago_venta_id, monto_recibido, vuelto) VALUES (13,10,0.00);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (11,'tarjeta',14.62);
INSERT INTO pago_tarjeta (pago_venta_id, tipo_tarjeta, marca, ultimos_4, codigo_autorizacion) VALUES (14,'CREDITO','Mastercard','4618','AUT100382');

-- Venta 12: Cayma · boleta B001 · total S/ 8.10
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (1,4,NULL,'BOLETA','B001',0,TIMESTAMP(CURDATE(),'12:15:00'),6.86,1.24,8.10);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (12,10,2,1.50,3.00),
 (12,12,2,1.80,3.60),
 (12,13,1,1.50,1.50);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (12,'efectivo',8.10);
INSERT INTO pago_efectivo (pago_venta_id, monto_recibido, vuelto) VALUES (15,10,1.90);

-- Venta 13: Cerro Colorado · boleta B002 · total S/ 17.90
INSERT INTO venta (tienda_id, caja_turno_id, cliente_id, tipo_comprobante, serie, correlativo, fecha, subtotal, igv, total) VALUES (2,6,NULL,'BOLETA','B002',0,TIMESTAMP(CURDATE(),'13:30:00'),15.17,2.73,17.90);
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, total_linea) VALUES
 (13,4,2,4.20,8.40),
 (13,5,1,9.50,9.50);
INSERT INTO pago_venta (venta_id, medio_pago, monto) VALUES (13,'efectivo',17.90);
INSERT INTO pago_efectivo (pago_venta_id, monto_recibido, vuelto) VALUES (16,20,2.10);

-- Venta 12 anulada con el procedimiento (devuelve stock y anula sus pagos)
CALL sp_anular_venta(12, 3, 'Cliente desistió de la compra');

-- Kardex: merma y ajustes de inventario (hacen que Cayma tenga productos con stock bajo)
INSERT INTO merma (tienda_id, producto_id, usuario_id, cantidad, motivo, observacion) VALUES (1,2,4,3,'VENCIDO','Yogures vencidos del lote de la semana pasada');
CALL sp_mover_stock(1,14,4,'AJUSTE_SALIDA',48,NULL,NULL,'Conteo físico: faltante en góndola');
CALL sp_mover_stock(1,17,4,'AJUSTE_SALIDA',50,NULL,NULL,'Conteo físico: faltante en góndola');
CALL sp_mover_stock(1,19,4,'AJUSTE_SALIDA',52,NULL,NULL,'Conteo físico: faltante en góndola');
CALL sp_mover_stock(1,15,4,'AJUSTE_SALIDA',47,NULL,NULL,'Conteo físico: faltante en góndola');
CALL sp_mover_stock(2,12,8,'AJUSTE_ENTRADA',10,NULL,NULL,'Conteo físico: sobrante');

SELECT 'Datos cargados correctamente' AS mensaje;
SELECT * FROM vw_control_ventas WHERE estado_cuadre <> 'OK';  -- debe devolver 0 filas
