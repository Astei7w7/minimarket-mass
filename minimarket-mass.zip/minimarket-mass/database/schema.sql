-- ============================================================
-- schema.sql · minimarket_mass · MySQL 8.0+ · InnoDB utf8mb4
-- 20 tablas (12 obligatorias + 8 propias) · 8 reglas de negocio
-- Convenciones: PK = id · FK = <tabla>_id · dinero DECIMAL(10,2)
-- ============================================================
DROP DATABASE IF EXISTS minimarket_mass;
CREATE DATABASE minimarket_mass CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE minimarket_mass;

-- ---------- Ubicación y personal ----------
CREATE TABLE distrito (
  id     TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(60) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_distrito_nombre (nombre)
) ENGINE=InnoDB;

CREATE TABLE tienda (
  id            TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  distrito_id   TINYINT UNSIGNED NOT NULL,
  codigo        VARCHAR(12)  NOT NULL,
  nombre        VARCHAR(80)  NOT NULL,
  direccion     VARCHAR(120) NOT NULL,
  telefono      VARCHAR(15)  NULL,
  serie_boleta  CHAR(4) NOT NULL,
  serie_factura CHAR(4) NOT NULL,
  ultimo_correlativo_boleta  INT UNSIGNED NOT NULL DEFAULT 0,
  ultimo_correlativo_factura INT UNSIGNED NOT NULL DEFAULT 0,
  activo        TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uk_tienda_codigo (codigo),
  UNIQUE KEY uk_tienda_distrito (distrito_id),           -- una tienda por distrito
  UNIQUE KEY uk_tienda_serie_boleta (serie_boleta),
  UNIQUE KEY uk_tienda_serie_factura (serie_factura),
  CONSTRAINT fk_tienda_distrito FOREIGN KEY (distrito_id) REFERENCES distrito (id),
  CONSTRAINT ck_tienda_serie_b CHECK (serie_boleta  REGEXP '^B[0-9]{3}$'),
  CONSTRAINT ck_tienda_serie_f CHECK (serie_factura REGEXP '^F[0-9]{3}$')
) ENGINE=InnoDB;

CREATE TABLE usuario (
  id        SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tienda_id TINYINT UNSIGNED NOT NULL,
  nombre    VARCHAR(100) NOT NULL,
  usuario   VARCHAR(40)  NOT NULL,
  clave     CHAR(60)     NOT NULL,                     -- hash bcrypt
  rol       ENUM('administrador','cajero','almacenero') NOT NULL,
  activo    TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uk_usuario_login (usuario),
  CONSTRAINT fk_usuario_tienda FOREIGN KEY (tienda_id) REFERENCES tienda (id)
) ENGINE=InnoDB;

-- ---------- Clientes ----------
CREATE TABLE cliente (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  tipo_documento   ENUM('DNI','RUC') NOT NULL,
  numero_documento VARCHAR(11) NOT NULL,
  nombre           VARCHAR(120) NOT NULL,
  telefono         VARCHAR(15) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_cliente_doc (tipo_documento, numero_documento),
  CONSTRAINT ck_cliente_documento CHECK (
    (tipo_documento = 'DNI' AND numero_documento REGEXP '^[0-9]{8}$') OR
    (tipo_documento = 'RUC' AND numero_documento REGEXP '^(10|20)[0-9]{9}$'))
) ENGINE=InnoDB;

-- ---------- Catálogo ----------
CREATE TABLE categoria (
  id     TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_categoria_nombre (nombre)
) ENGINE=InnoDB;

CREATE TABLE marca (
  id        SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre    VARCHAR(50) NOT NULL,
  es_propia TINYINT(1) NOT NULL DEFAULT 0,               -- marca propia del grupo
  PRIMARY KEY (id),
  UNIQUE KEY uk_marca_nombre (nombre)
) ENGINE=InnoDB;

CREATE TABLE unidad_medida (
  id                TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  abreviatura       VARCHAR(5)  NOT NULL,
  nombre            VARCHAR(30) NOT NULL,
  permite_decimales TINYINT(1) NOT NULL DEFAULT 0,       -- kg y litro: 1
  PRIMARY KEY (id),
  UNIQUE KEY uk_unidad_abrev (abreviatura)
) ENGINE=InnoDB;

CREATE TABLE producto (
  id               SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  categoria_id     TINYINT UNSIGNED NOT NULL,
  marca_id         SMALLINT UNSIGNED NOT NULL,
  unidad_medida_id TINYINT UNSIGNED NOT NULL,
  codigo_barras    CHAR(13) NULL,                        -- EAN-13
  nombre           VARCHAR(100) NOT NULL,
  precio           DECIMAL(10,2) NOT NULL,               -- IGV 18 % incluido
  activo           TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uk_producto_barras (codigo_barras),
  CONSTRAINT fk_producto_categoria FOREIGN KEY (categoria_id)     REFERENCES categoria (id),
  CONSTRAINT fk_producto_marca     FOREIGN KEY (marca_id)         REFERENCES marca (id),
  CONSTRAINT fk_producto_unidad    FOREIGN KEY (unidad_medida_id) REFERENCES unidad_medida (id),
  CONSTRAINT ck_producto_precio CHECK (precio > 0),
  CONSTRAINT ck_producto_barras CHECK (codigo_barras IS NULL OR codigo_barras REGEXP '^[0-9]{13}$')
) ENGINE=InnoDB;

-- ---------- Inventario ----------
CREATE TABLE stock (
  tienda_id   TINYINT UNSIGNED NOT NULL,
  producto_id SMALLINT UNSIGNED NOT NULL,
  cantidad    DECIMAL(10,3) NOT NULL DEFAULT 0,
  PRIMARY KEY (tienda_id, producto_id),
  CONSTRAINT fk_stock_tienda   FOREIGN KEY (tienda_id)   REFERENCES tienda (id),
  CONSTRAINT fk_stock_producto FOREIGN KEY (producto_id) REFERENCES producto (id),
  CONSTRAINT ck_stock_no_negativo CHECK (cantidad >= 0)
) ENGINE=InnoDB;

-- ---------- Caja ----------
CREATE TABLE caja (
  id        SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tienda_id TINYINT UNSIGNED NOT NULL,
  numero    TINYINT UNSIGNED NOT NULL,
  activo    TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uk_caja_numero (tienda_id, numero),
  CONSTRAINT fk_caja_tienda FOREIGN KEY (tienda_id) REFERENCES tienda (id)
) ENGINE=InnoDB;

CREATE TABLE caja_turno (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  caja_id       SMALLINT UNSIGNED NOT NULL,
  tienda_id     TINYINT UNSIGNED NOT NULL,
  usuario_id    SMALLINT UNSIGNED NOT NULL,              -- cajero
  apertura      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cierre        DATETIME NULL,
  monto_inicial DECIMAL(10,2) NOT NULL DEFAULT 0,
  monto_final   DECIMAL(10,2) NULL,
  estado        ENUM('ABIERTO','CERRADO') NOT NULL DEFAULT 'ABIERTO',
  -- columnas generadas: permiten un UNIQUE "solo mientras está ABIERTO"
  caja_abierta    SMALLINT UNSIGNED GENERATED ALWAYS AS (IF(estado='ABIERTO', caja_id, NULL)) STORED,
  usuario_abierto SMALLINT UNSIGNED GENERATED ALWAYS AS (IF(estado='ABIERTO', usuario_id, NULL)) STORED,
  PRIMARY KEY (id),
  UNIQUE KEY uk_turno_caja_abierta (caja_abierta),
  UNIQUE KEY uk_turno_usuario_abierto (usuario_abierto),
  CONSTRAINT fk_turno_caja    FOREIGN KEY (caja_id)    REFERENCES caja (id),
  CONSTRAINT fk_turno_tienda  FOREIGN KEY (tienda_id)  REFERENCES tienda (id),
  CONSTRAINT fk_turno_usuario FOREIGN KEY (usuario_id) REFERENCES usuario (id),
  CONSTRAINT ck_turno_montos CHECK (monto_inicial >= 0 AND (monto_final IS NULL OR monto_final >= 0)),
  CONSTRAINT ck_turno_cierre CHECK (
    (estado = 'ABIERTO' AND cierre IS NULL) OR (estado = 'CERRADO' AND cierre IS NOT NULL))
) ENGINE=InnoDB;

-- ---------- Ventas ----------
CREATE TABLE venta (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  tienda_id        TINYINT UNSIGNED NOT NULL,
  caja_turno_id    INT UNSIGNED NOT NULL,
  cliente_id       INT UNSIGNED NULL,                    -- NULL = boleta al público
  tipo_comprobante ENUM('BOLETA','FACTURA') NOT NULL,
  serie            CHAR(4) NOT NULL,
  correlativo      INT UNSIGNED NOT NULL,                -- 0 = lo asigna el trigger
  fecha            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  subtotal         DECIMAL(10,2) NOT NULL,               -- base imponible
  igv              DECIMAL(10,2) NOT NULL,
  total            DECIMAL(10,2) NOT NULL,
  estado           ENUM('EMITIDA','ANULADA') NOT NULL DEFAULT 'EMITIDA',
  PRIMARY KEY (id),
  UNIQUE KEY uk_venta_serie_correlativo (serie, correlativo),
  KEY ix_venta_fecha (fecha),
  CONSTRAINT fk_venta_tienda  FOREIGN KEY (tienda_id)     REFERENCES tienda (id),
  CONSTRAINT fk_venta_turno   FOREIGN KEY (caja_turno_id) REFERENCES caja_turno (id),
  CONSTRAINT fk_venta_cliente FOREIGN KEY (cliente_id)    REFERENCES cliente (id),
  CONSTRAINT ck_venta_totales CHECK (total = subtotal + igv AND subtotal >= 0 AND igv >= 0 AND total > 0),
  CONSTRAINT ck_venta_factura CHECK (tipo_comprobante = 'BOLETA' OR cliente_id IS NOT NULL)
) ENGINE=InnoDB;

CREATE TABLE detalle_venta (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  venta_id        INT UNSIGNED NOT NULL,
  producto_id     SMALLINT UNSIGNED NOT NULL,
  cantidad        DECIMAL(10,3) NOT NULL,
  precio_unitario DECIMAL(10,2) NOT NULL,                -- copia del precio al vender
  total_linea     DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (id),
  KEY ix_detalle_venta (venta_id),
  KEY ix_detalle_producto (producto_id),
  CONSTRAINT fk_detalle_venta    FOREIGN KEY (venta_id)    REFERENCES venta (id),
  CONSTRAINT fk_detalle_producto FOREIGN KEY (producto_id) REFERENCES producto (id),
  CONSTRAINT ck_detalle_cantidad CHECK (cantidad > 0),
  CONSTRAINT ck_detalle_total    CHECK (total_linea = ROUND(cantidad * precio_unitario, 2))
) ENGINE=InnoDB;

CREATE TABLE anulacion_venta (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  venta_id   INT UNSIGNED NOT NULL,
  usuario_id SMALLINT UNSIGNED NOT NULL,
  fecha      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  motivo     VARCHAR(150) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_anulacion_venta (venta_id),              -- una venta se anula una vez
  CONSTRAINT fk_anul_venta   FOREIGN KEY (venta_id)   REFERENCES venta (id),
  CONSTRAINT fk_anul_usuario FOREIGN KEY (usuario_id) REFERENCES usuario (id)
) ENGINE=InnoDB;

-- ---------- Pagos ----------
CREATE TABLE pago_venta (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  venta_id   INT UNSIGNED NOT NULL,
  medio_pago ENUM('efectivo','tarjeta','yape','plin') NOT NULL,
  monto      DECIMAL(10,2) NOT NULL,
  estado     ENUM('APLICADO','ANULADO') NOT NULL DEFAULT 'APLICADO',
  PRIMARY KEY (id),
  KEY ix_pago_venta (venta_id),
  CONSTRAINT fk_pago_venta FOREIGN KEY (venta_id) REFERENCES venta (id),
  CONSTRAINT ck_pago_monto CHECK (monto > 0)
) ENGINE=InnoDB;

CREATE TABLE pago_efectivo (
  pago_venta_id  INT UNSIGNED NOT NULL,
  monto_recibido DECIMAL(10,2) NOT NULL,
  vuelto         DECIMAL(10,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (pago_venta_id),
  CONSTRAINT fk_pefe_pago FOREIGN KEY (pago_venta_id) REFERENCES pago_venta (id),
  CONSTRAINT ck_pefe CHECK (monto_recibido > 0 AND vuelto >= 0 AND vuelto < monto_recibido)
) ENGINE=InnoDB;

CREATE TABLE pago_tarjeta (
  pago_venta_id       INT UNSIGNED NOT NULL,
  tipo_tarjeta        ENUM('DEBITO','CREDITO') NOT NULL,
  marca               VARCHAR(20) NOT NULL,
  ultimos_4           CHAR(4) NOT NULL,                  -- nunca el número completo
  codigo_autorizacion VARCHAR(10) NOT NULL,
  PRIMARY KEY (pago_venta_id),
  CONSTRAINT fk_ptar_pago FOREIGN KEY (pago_venta_id) REFERENCES pago_venta (id),
  CONSTRAINT ck_ptar_ult4 CHECK (ultimos_4 REGEXP '^[0-9]{4}$')
) ENGINE=InnoDB;

CREATE TABLE pago_billetera (
  pago_venta_id    INT UNSIGNED NOT NULL,
  codigo_operacion VARCHAR(30) NOT NULL,
  telefono_origen  CHAR(9) NULL,
  PRIMARY KEY (pago_venta_id),
  UNIQUE KEY uk_pbil_operacion (codigo_operacion),
  CONSTRAINT fk_pbil_pago FOREIGN KEY (pago_venta_id) REFERENCES pago_venta (id),
  CONSTRAINT ck_pbil_tel CHECK (telefono_origen IS NULL OR telefono_origen REGEXP '^9[0-9]{8}$')
) ENGINE=InnoDB;

-- ---------- Mermas y kardex ----------
CREATE TABLE merma (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  tienda_id   TINYINT UNSIGNED NOT NULL,
  producto_id SMALLINT UNSIGNED NOT NULL,
  usuario_id  SMALLINT UNSIGNED NOT NULL,
  cantidad    DECIMAL(10,3) NOT NULL,
  motivo      ENUM('VENCIDO','DETERIORADO','ROBO','OTRO') NOT NULL,
  fecha       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  observacion VARCHAR(200) NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_merma_tienda   FOREIGN KEY (tienda_id)   REFERENCES tienda (id),
  CONSTRAINT fk_merma_producto FOREIGN KEY (producto_id) REFERENCES producto (id),
  CONSTRAINT fk_merma_usuario  FOREIGN KEY (usuario_id)  REFERENCES usuario (id),
  CONSTRAINT ck_merma_cantidad CHECK (cantidad > 0)
) ENGINE=InnoDB;

CREATE TABLE movimiento_stock (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  tienda_id        TINYINT UNSIGNED NOT NULL,
  producto_id      SMALLINT UNSIGNED NOT NULL,
  usuario_id       SMALLINT UNSIGNED NULL,
  tipo             ENUM('VENTA','ANULACION','MERMA','AJUSTE_ENTRADA','AJUSTE_SALIDA') NOT NULL,
  cantidad         DECIMAL(10,3) NOT NULL,               -- siempre positiva
  stock_resultante DECIMAL(10,3) NOT NULL,
  venta_id         INT UNSIGNED NULL,
  merma_id         INT UNSIGNED NULL,
  observacion      VARCHAR(200) NULL,
  fecha            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_mov_producto (tienda_id, producto_id, fecha),
  CONSTRAINT fk_mov_stock   FOREIGN KEY (tienda_id, producto_id) REFERENCES stock (tienda_id, producto_id),
  CONSTRAINT fk_mov_usuario FOREIGN KEY (usuario_id) REFERENCES usuario (id),
  CONSTRAINT fk_mov_venta   FOREIGN KEY (venta_id)   REFERENCES venta (id),
  CONSTRAINT fk_mov_merma   FOREIGN KEY (merma_id)   REFERENCES merma (id),
  CONSTRAINT ck_mov_cantidad CHECK (cantidad > 0),
  CONSTRAINT ck_mov_origen CHECK (
    (tipo IN ('VENTA','ANULACION') AND venta_id IS NOT NULL AND merma_id IS NULL) OR
    (tipo = 'MERMA' AND merma_id IS NOT NULL AND venta_id IS NULL) OR
    (tipo IN ('AJUSTE_ENTRADA','AJUSTE_SALIDA') AND venta_id IS NULL AND merma_id IS NULL))
) ENGINE=InnoDB;

-- ============================================================
-- Procedimientos y triggers
-- ============================================================
DELIMITER //

-- Único punto por donde cambia el stock (RN-05): valida, actualiza y deja kardex
CREATE PROCEDURE sp_mover_stock(
  IN p_tienda TINYINT UNSIGNED, IN p_producto SMALLINT UNSIGNED, IN p_usuario SMALLINT UNSIGNED,
  IN p_tipo VARCHAR(20), IN p_cantidad DECIMAL(10,3),
  IN p_venta INT UNSIGNED, IN p_merma INT UNSIGNED, IN p_obs VARCHAR(200))
BEGIN
  DECLARE v_actual DECIMAL(10,3);
  DECLARE v_nuevo  DECIMAL(10,3);
  SELECT cantidad INTO v_actual FROM stock
   WHERE tienda_id = p_tienda AND producto_id = p_producto FOR UPDATE;
  IF v_actual IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El producto no tiene stock registrado en la tienda';
  END IF;
  IF p_tipo IN ('VENTA','MERMA','AJUSTE_SALIDA') THEN
    IF v_actual < p_cantidad THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stock insuficiente: el stock no puede quedar negativo';
    END IF;
    SET v_nuevo = v_actual - p_cantidad;
  ELSE
    SET v_nuevo = v_actual + p_cantidad;
  END IF;
  UPDATE stock SET cantidad = v_nuevo WHERE tienda_id = p_tienda AND producto_id = p_producto;
  INSERT INTO movimiento_stock (tienda_id, producto_id, usuario_id, tipo, cantidad, stock_resultante, venta_id, merma_id, observacion)
  VALUES (p_tienda, p_producto, p_usuario, p_tipo, p_cantidad, v_nuevo, p_venta, p_merma, p_obs);
END//

-- RN-07 y RN-08: solo un cajero de la tienda abre turno en una caja de esa tienda
CREATE TRIGGER trg_turno_bi BEFORE INSERT ON caja_turno FOR EACH ROW
BEGIN
  DECLARE v_rol VARCHAR(20); DECLARE v_tu TINYINT UNSIGNED; DECLARE v_tc TINYINT UNSIGNED;
  SELECT rol, tienda_id INTO v_rol, v_tu FROM usuario WHERE id = NEW.usuario_id;
  SELECT tienda_id INTO v_tc FROM caja WHERE id = NEW.caja_id;
  IF v_rol <> 'cajero' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Solo un usuario con rol cajero abre un turno de caja';
  END IF;
  IF v_tu <> NEW.tienda_id OR v_tc <> NEW.tienda_id THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El cajero y la caja deben ser de la tienda del turno';
  END IF;
END//

-- RN-01, RN-02, RN-07: serie y correlativo, factura con RUC, turno abierto
CREATE TRIGGER trg_venta_bi BEFORE INSERT ON venta FOR EACH ROW
BEGIN
  DECLARE v_estado VARCHAR(10); DECLARE v_tt TINYINT UNSIGNED;
  DECLARE v_sb CHAR(4); DECLARE v_sf CHAR(4); DECLARE v_doc VARCHAR(3); DECLARE v_corr INT UNSIGNED;
  SELECT estado, tienda_id INTO v_estado, v_tt FROM caja_turno WHERE id = NEW.caja_turno_id;
  IF v_estado <> 'ABIERTO' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Solo se vende con un turno de caja abierto';
  END IF;
  IF v_tt <> NEW.tienda_id THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El turno no pertenece a la tienda de la venta';
  END IF;
  SELECT serie_boleta, serie_factura INTO v_sb, v_sf FROM tienda WHERE id = NEW.tienda_id;
  IF (NEW.tipo_comprobante = 'BOLETA'  AND NEW.serie <> v_sb) OR
     (NEW.tipo_comprobante = 'FACTURA' AND NEW.serie <> v_sf) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La serie no corresponde a la tienda y al tipo de comprobante';
  END IF;
  IF NEW.tipo_comprobante = 'FACTURA' THEN
    SELECT tipo_documento INTO v_doc FROM cliente WHERE id = NEW.cliente_id;
    IF v_doc IS NULL OR v_doc <> 'RUC' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La factura exige un cliente con RUC de 11 digitos';
    END IF;
  END IF;
  IF NEW.correlativo = 0 THEN                         -- correlativo automático por tienda y tipo
    IF NEW.tipo_comprobante = 'BOLETA' THEN
      UPDATE tienda SET ultimo_correlativo_boleta = ultimo_correlativo_boleta + 1 WHERE id = NEW.tienda_id;
      SELECT ultimo_correlativo_boleta INTO v_corr FROM tienda WHERE id = NEW.tienda_id;
    ELSE
      UPDATE tienda SET ultimo_correlativo_factura = ultimo_correlativo_factura + 1 WHERE id = NEW.tienda_id;
      SELECT ultimo_correlativo_factura INTO v_corr FROM tienda WHERE id = NEW.tienda_id;
    END IF;
    SET NEW.correlativo = v_corr;
  END IF;
END//

-- RN-04: las ventas no se borran ni se reviven
CREATE TRIGGER trg_venta_no_delete BEFORE DELETE ON venta FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Las ventas no se borran: use sp_anular_venta';
END//
CREATE TRIGGER trg_venta_bu BEFORE UPDATE ON venta FOR EACH ROW
BEGIN
  IF OLD.estado = 'ANULADA' AND NEW.estado <> 'ANULADA' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Una venta anulada no puede volver a emitida';
  END IF;
END//

-- RN-05: cada línea de venta descuenta stock y deja movimiento
CREATE TRIGGER trg_detalle_venta_ai AFTER INSERT ON detalle_venta FOR EACH ROW
BEGIN
  DECLARE v_tienda TINYINT UNSIGNED; DECLARE v_estado VARCHAR(10); DECLARE v_cajero SMALLINT UNSIGNED;
  SELECT v.tienda_id, v.estado, ct.usuario_id INTO v_tienda, v_estado, v_cajero
    FROM venta v JOIN caja_turno ct ON ct.id = v.caja_turno_id WHERE v.id = NEW.venta_id;
  IF v_estado = 'EMITIDA' THEN
    CALL sp_mover_stock(v_tienda, NEW.producto_id, v_cajero, 'VENTA', NEW.cantidad, NEW.venta_id, NULL, NULL);
  END IF;
END//

-- Merma: descuenta stock con su motivo
CREATE TRIGGER trg_merma_ai AFTER INSERT ON merma FOR EACH ROW
BEGIN
  CALL sp_mover_stock(NEW.tienda_id, NEW.producto_id, NEW.usuario_id, 'MERMA', NEW.cantidad, NULL, NEW.id, NEW.motivo);
END//

-- RN-06: cada detalle de pago coincide con su medio
CREATE TRIGGER trg_pago_efectivo_bi BEFORE INSERT ON pago_efectivo FOR EACH ROW
BEGIN
  DECLARE v_medio VARCHAR(10); DECLARE v_monto DECIMAL(10,2);
  SELECT medio_pago, monto INTO v_medio, v_monto FROM pago_venta WHERE id = NEW.pago_venta_id;
  IF v_medio <> 'efectivo' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El pago no es en efectivo';
  END IF;
  IF NEW.monto_recibido - NEW.vuelto <> v_monto THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Monto recibido menos vuelto debe ser igual al monto del pago';
  END IF;
END//
CREATE TRIGGER trg_pago_tarjeta_bi BEFORE INSERT ON pago_tarjeta FOR EACH ROW
BEGIN
  DECLARE v_medio VARCHAR(10);
  SELECT medio_pago INTO v_medio FROM pago_venta WHERE id = NEW.pago_venta_id;
  IF v_medio <> 'tarjeta' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El pago no es con tarjeta'; END IF;
END//
CREATE TRIGGER trg_pago_billetera_bi BEFORE INSERT ON pago_billetera FOR EACH ROW
BEGIN
  DECLARE v_medio VARCHAR(10);
  SELECT medio_pago INTO v_medio FROM pago_venta WHERE id = NEW.pago_venta_id;
  IF v_medio NOT IN ('yape','plin') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El pago no es con Yape o Plin'; END IF;
END//

-- Anular: registra quién, cuándo y por qué; anula pagos y devuelve stock
CREATE PROCEDURE sp_anular_venta(IN p_venta INT UNSIGNED, IN p_usuario SMALLINT UNSIGNED, IN p_motivo VARCHAR(150))
BEGIN
  DECLARE v_estado VARCHAR(10); DECLARE v_tienda TINYINT UNSIGNED; DECLARE v_rol VARCHAR(20);
  DECLARE fin INT DEFAULT 0; DECLARE d_prod SMALLINT UNSIGNED; DECLARE d_cant DECIMAL(10,3);
  DECLARE cur CURSOR FOR SELECT producto_id, cantidad FROM detalle_venta WHERE venta_id = p_venta;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET fin = 1;
  SELECT estado, tienda_id INTO v_estado, v_tienda FROM venta WHERE id = p_venta FOR UPDATE;
  IF v_estado IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La venta no existe'; END IF;
  IF v_estado = 'ANULADA' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La venta ya esta anulada'; END IF;
  SELECT rol INTO v_rol FROM usuario WHERE id = p_usuario;
  IF v_rol IS NULL OR v_rol NOT IN ('administrador','cajero') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Solo administrador o cajero puede anular ventas';
  END IF;
  UPDATE venta SET estado = 'ANULADA' WHERE id = p_venta;
  INSERT INTO anulacion_venta (venta_id, usuario_id, motivo) VALUES (p_venta, p_usuario, p_motivo);
  UPDATE pago_venta SET estado = 'ANULADO' WHERE venta_id = p_venta;
  SET fin = 0;
  OPEN cur;
  lp: LOOP
    FETCH cur INTO d_prod, d_cant;
    IF fin = 1 THEN LEAVE lp; END IF;
    CALL sp_mover_stock(v_tienda, d_prod, p_usuario, 'ANULACION', d_cant, p_venta, NULL, p_motivo);
  END LOOP;
  CLOSE cur;
END//

DELIMITER ;

-- RN-06: la suma de pagos debe igualar el total. Se controla con una vista
-- porque los pagos se registran después de la venta.
CREATE VIEW vw_control_ventas AS
SELECT v.id AS venta_id, v.serie, v.correlativo, v.total AS total_venta,
       (SELECT COALESCE(SUM(dv.total_linea),0) FROM detalle_venta dv WHERE dv.venta_id = v.id) AS total_lineas,
       (SELECT COALESCE(SUM(p.monto),0) FROM pago_venta p WHERE p.venta_id = v.id AND p.estado = 'APLICADO') AS total_pagado,
       CASE WHEN v.total = (SELECT COALESCE(SUM(dv.total_linea),0) FROM detalle_venta dv WHERE dv.venta_id = v.id)
             AND v.total = (SELECT COALESCE(SUM(p.monto),0) FROM pago_venta p WHERE p.venta_id = v.id AND p.estado = 'APLICADO')
            THEN 'OK' ELSE 'DESCUADRE' END AS estado_cuadre
FROM venta v WHERE v.estado = 'EMITIDA';
